<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
</head>
<body>
 	<?php
 		echo "iai mundo ";
 	?>
</body>
</html>